// Auto-generated. Do not edit!

// (in-package ros_broker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GSDFPacket {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.packet_source = null;
      this.packet_version = null;
      this.packet_type = null;
      this.packet_data = null;
      this.package_check_sum = null;
    }
    else {
      if (initObj.hasOwnProperty('packet_source')) {
        this.packet_source = initObj.packet_source
      }
      else {
        this.packet_source = 0;
      }
      if (initObj.hasOwnProperty('packet_version')) {
        this.packet_version = initObj.packet_version
      }
      else {
        this.packet_version = 0;
      }
      if (initObj.hasOwnProperty('packet_type')) {
        this.packet_type = initObj.packet_type
      }
      else {
        this.packet_type = 0;
      }
      if (initObj.hasOwnProperty('packet_data')) {
        this.packet_data = initObj.packet_data
      }
      else {
        this.packet_data = '';
      }
      if (initObj.hasOwnProperty('package_check_sum')) {
        this.package_check_sum = initObj.package_check_sum
      }
      else {
        this.package_check_sum = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GSDFPacket
    // Serialize message field [packet_source]
    bufferOffset = _serializer.int16(obj.packet_source, buffer, bufferOffset);
    // Serialize message field [packet_version]
    bufferOffset = _serializer.int8(obj.packet_version, buffer, bufferOffset);
    // Serialize message field [packet_type]
    bufferOffset = _serializer.int8(obj.packet_type, buffer, bufferOffset);
    // Serialize message field [packet_data]
    bufferOffset = _serializer.string(obj.packet_data, buffer, bufferOffset);
    // Serialize message field [package_check_sum]
    bufferOffset = _serializer.int64(obj.package_check_sum, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GSDFPacket
    let len;
    let data = new GSDFPacket(null);
    // Deserialize message field [packet_source]
    data.packet_source = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [packet_version]
    data.packet_version = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [packet_type]
    data.packet_type = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [packet_data]
    data.packet_data = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [package_check_sum]
    data.package_check_sum = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.packet_data.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ros_broker/GSDFPacket';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a47802d49bd3f71134b8d47283707f92';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 packet_source
    int8 packet_version
    int8 packet_type
    string packet_data
    int64 package_check_sum
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GSDFPacket(null);
    if (msg.packet_source !== undefined) {
      resolved.packet_source = msg.packet_source;
    }
    else {
      resolved.packet_source = 0
    }

    if (msg.packet_version !== undefined) {
      resolved.packet_version = msg.packet_version;
    }
    else {
      resolved.packet_version = 0
    }

    if (msg.packet_type !== undefined) {
      resolved.packet_type = msg.packet_type;
    }
    else {
      resolved.packet_type = 0
    }

    if (msg.packet_data !== undefined) {
      resolved.packet_data = msg.packet_data;
    }
    else {
      resolved.packet_data = ''
    }

    if (msg.package_check_sum !== undefined) {
      resolved.package_check_sum = msg.package_check_sum;
    }
    else {
      resolved.package_check_sum = 0
    }

    return resolved;
    }
};

module.exports = GSDFPacket;
