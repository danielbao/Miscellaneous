#ifndef CCPP_GSDFPACKET_H
#define CCPP_GSDFPACKET_H

#include "ccpp.h"
#include "GSDFPacket.h"
#include "GSDFPacketDcps.h"
#include <orb_abstraction.h>
#include "GSDFPacketDcps_impl.h"

#endif /* CCPP_GSDFPACKET_H */
